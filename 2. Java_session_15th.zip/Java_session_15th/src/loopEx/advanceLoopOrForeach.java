package loopEx;

public class advanceLoopOrForeach {

	public static void main(String[] args) {

		int d[] = {111,2,2,2,3,4,3444,3,3,22,2,2}; //array
		
		//read/access every eleent from given list/array/collection
		for(int n : d)//foreach , forward only
		{
			System.out.println(n);
		}

	}

}
