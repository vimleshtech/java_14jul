package loopEx;

import java.util.Scanner;

public class whileLoop {

	public static void main(String[] aa)
	{
		//init
		int i=0;
		
		while(i<10)//condition
		{
			//System.out.println(i); //print then change line
			System.out.print(i); //print in same line 
			i++; //incrementer
		}
		
		System.out.println();
		
		//print in reverse order
		i =10;
		while(i>0)
		{
			System.out.println(i);
			i--;
		}
		//print all odd numbers between 1 to 30
		i =1;
		while(i<=30)
		{
			System.out.println(i);
			i+=2; //i=i+2
 			
		}
		
		
		//wap to get sum or all even and odd numbers between 1 to 100
		int se=0, so=0;
		i =1;
		while(i<=100)
		{
			if(i%2==0)
			{
				se=se+i;
			}
			else
			{
				so+=i;
			}
			i++;
		}
		System.out.println("sum of all even no :"+se);
		System.out.println("sum of all odd no :"+so);
		
		
		//wap to print table of given no.
		int t;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter no. to print table : ");
		t =sc.nextInt();
		
		i =1;
		while(i<=10)
		{
				//System.out.println(t*i);
				System.out.println(t+"*"+i+"="+(t*i));
				
				i++;
		}
		
	}
}
