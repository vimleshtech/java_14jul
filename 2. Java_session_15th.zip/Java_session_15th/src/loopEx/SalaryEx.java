package loopEx;

import java.util.Scanner;

public class SalaryEx {

	public static void main(String[] args) {
	int units=0;
	double bill;
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the units ");
	units=s.nextInt();
	
	if(units<=100)
	{
		bill=units*(.40);
		System.out.println(bill+50);
	}
	else if(units>100 && units<=300)
	{
		units=units-100;
		bill=40+units*.50;
		System.out.println(bill+50);
		
	}
	else if(units>300)
	{
		units=units-300;
		bill=140+units*(.60);
		System.out.println(bill+50);
	}
	
	}

}
