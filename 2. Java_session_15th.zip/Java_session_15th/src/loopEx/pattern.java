package loopEx;

import java.util.Scanner;

public class pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,i=1,sum=0;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		for(i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				sum=sum+j;
			}
		}System.out.println(sum);
	}

}
