package loopEx;

public class forEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=0; i<10;i++)
			System.out.println(i);
		
		//print in reverse
		for(int i=10;i>0;i--)
		{
			System.out.println(i);
		}
		//table of 2
		for(int i=2;i<=20;i=i+2)
		{
			System.out.println(i);
		}
		
	}

}
