package loopEx;

import java.util.Scanner;

public class Between {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,i=0,sum=0;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number ");
		a=sc.nextInt();
		b=sc.nextInt();
		for(i=a;i<=b;i++)
		{
			if(i%2==0)
			{
				if(i%5!=0 && i%3==0)
				{
					sum=sum+i;
				}		
				
			}
			
		}
		System.out.println(sum);
	}

}
