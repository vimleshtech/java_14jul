package questions;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class ifExample {

	public static void main(String[] args) {

		int a,b,c;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter n1: ");
		a =sc.nextInt();
		
		System.out.println("enter n2: ");
		b =sc.nextInt();
		
		System.out.println("enter n3: ");
		c =sc.nextInt();
		
		//show if given no. is even : if condition 
		if( a%2 == 0)
		{
			System.out.println("even no.");
		}
				
		//show greater no. : if else 
		if (a>b)		
			System.out.println("a is greater");		
		else
			System.out.println("b is greater");
		
		
		//if else if else if ....  : ladder if else
		if (a>b && a>c)		
		{
			System.out.println("a is greater");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is greater");
		}
		else
		{
			System.out.println("c is greater");
		}
		
		//nested if else 
		if (a>b)
		{
				if(a>c)
				{
					System.out.println("a is gt");
				}
				else
				{
					System.out.println("c is gt");
				}
		}
		else
		{
			if(b>c)
			{
				System.out.println("b is gt");
			}
			else
			{
				System.out.println("c is gt");
			}
		}
		
	}

}
