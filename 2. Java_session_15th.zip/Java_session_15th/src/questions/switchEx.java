package questions;

import java.util.Scanner;

public class switchEx {

	public static void main(String[] args) {

		int ch,a,b,c=0;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter your choice 1. for add 2. sub 3. for mul :");
		ch = sc.nextInt();
		
		System.out.println("enter first no : ");
		a = sc.nextInt();
		System.out.println("enter 2nd no : ");
		b = sc.nextInt();
		
		switch(ch)
		{
		
			case 1:
				c =a+b;
				break;
			case 2:
				c =a-b;
				break;
			case 3:
				c =a*b;
				break;
			default:
				System.out.println("invalid choice");
		}
		System.out.println(c);
		

	}

}
