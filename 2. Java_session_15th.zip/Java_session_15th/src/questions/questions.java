package questions;

import java.util.Scanner;

public class questions {

	public static void main(String[] args) {
	
		int n;
		double d1;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter no. ");
		n =sc.nextInt();
		
		
		System.out.println("enter no. ");
		d1 = sc.nextDouble();
		
		
		//n =n^2;
				
		System.out.println(n*n);
		System.out.println(n*n*n);
		
		//
		d1 = d1*3.14;
		System.out.println(d1);
	}

}
