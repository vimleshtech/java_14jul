package incomemetax;
import java.util.Scanner;
public class q1 {

	public static void main(String[] args) {
		int roll_no,marks;
		long phone_no;
		String name;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Roll No");
		roll_no= sc.nextInt();
		System.out.println("Enter the Phone no");
		phone_no= sc.nextInt();
		System.out.println("Enter the Marks");
		marks=sc.nextInt();
		System.out.println("Enter the Name");
		name= sc.next();
		System.out.println("Roll No is "+roll_no);
		System.out.println("Phone no is "+phone_no);
		System.out.println("Marks no is "+marks);
		System.out.println("Name is "+name);
		
		
		
		

	}

}
