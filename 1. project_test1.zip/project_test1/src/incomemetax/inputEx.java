package incomemetax;

import java.util.Scanner;
public class inputEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//here Scanner is inbuitl class
		//sc is an object/instance
		Scanner sc =new Scanner(System.in);
		int hs,es,total;
		
		System.out.println("enter data ");
		hs = sc.nextInt();
		
		System.out.println("enter data ");
		es = sc.nextInt();
		
		total = hs+es;
		System.out.println("total socre  is "+total);
		
		
	}

}
