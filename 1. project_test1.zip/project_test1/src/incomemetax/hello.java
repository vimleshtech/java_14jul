package incomemetax;

public class hello
{
	
	public static void main(String[] ab) 
	{
	
		//input /raw
		int hs,es,cs,ms,total; //here int is data type and hs,es....variables
		float avg;
		
		hs =77;
		es =70;
		cs =97;
		ms =87;
		
		//logic /steps/ expression
		total =hs+es+cs+ms;
		avg = total/4;
		
		
		//output
		System.out.println("total score is "+total);
		System.out.println("average score is "+avg);
		
	}

}
