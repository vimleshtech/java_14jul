package incomemetax;

import java.util.Scanner;

public class q2 {

	public static void main(String[] args) {
		int roll_no,i=1,n=5;
		int eng,hindi,maths,science,sst;
		double avg;
		long phone_no;
		String name;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Roll No");
		roll_no= sc.nextInt();
		System.out.println("Enter the Phone no");
		phone_no= sc.nextInt();
		System.out.println("Enter the Marks in eng");
		eng=sc.nextInt();
		System.out.println("Enter the Marks in Hindi");
		hindi=sc.nextInt();
		System.out.println("Enter the Marks in science");
		science=sc.nextInt();
		System.out.println("Enter the Marks in maths");
		maths=sc.nextInt();
		System.out.println("Enter the Marks in sst");
		sst=sc.nextInt();
		System.out.println("Enter the Name");
		name= sc.next();
		System.out.println("Roll No is "+roll_no);
		System.out.println("Phone no is "+phone_no);
		System.out.println("Marks are "+ eng + hindi + science + maths +sst);
		System.out.println("Name is "+name);
		avg=(eng+hindi+science+sst+maths)/5;
		System.out.println("Avg of marks is "+avg);
		System.out.println();
	}

}
