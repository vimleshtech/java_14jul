package incomemetax;

public class variableEx {

	//global variable 
	static int a; //static variable 
	int c; //instance variable 
	
	public static void main(String[] args) 
	{
		int b; //local variable 
		b =33;
		a =33;
		
		//create object or class variableEx
		variableEx o  =new variableEx();//new is keyword to allocate the memory
		o.c =33;
		
		System.out.println(a);
		System.out.println(b);
	}

	public static void test()
	{
		System.out.println(a);
		//System.out.println(b);
	}
}
