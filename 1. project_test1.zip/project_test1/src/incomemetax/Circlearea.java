package incomemetax;

import java.util.Scanner;

public class Circlearea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int radius;
		double area, cir;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the radium of the circle");
		radius=sc.nextInt();
		area=3.14*(radius*radius);
		cir=2*3.14*radius;
		System.out.println("Area of circle is "+area);
		System.out.println("Circumference of circle is "+cir);

	}

}
