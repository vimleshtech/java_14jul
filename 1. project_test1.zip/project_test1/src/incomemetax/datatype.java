package incomemetax;

public class datatype {

	public static void main(String[] args) 
	{
	
		byte b=1;
		short s=3333;
		int i=143333;
		long  l=3323223;
		
		float data=1.333f;
		double d =3433.322222;
		
		char c ='$';
		
		String name ="shish skjshjss32322";
		boolean bb =true;
		
		System.out.println(b);
		System.out.println(name);
	}

}
