package tax;

public class example2 {

	public static void main(String[] args) 
	{
	
		// input / raw data
		int n=123;
		int a,b,c;
		
		// logic / expression
		a = n/100;  //1
		b = (n/10)%10; //2
		c =n%10; // 3
		
		
		// output
		//println() ; print and chnage the line
		//print() ; print 
		System.out.print(c);
		System.out.print(b);
		System.out.print(a);
		
	}

}
