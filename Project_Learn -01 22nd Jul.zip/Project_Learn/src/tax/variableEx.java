package tax;

import java.util.ArrayList;

public class variableEx {

	//global varibale
	int a; //instance variable
	static int b; //static variable 
	
	
	public static void main(String[] args) 
	{
		int d=10; //local variable
		
		System.out.println(d);
		System.out.println(b);
		
		variableEx o =new variableEx();
		o.a =333;
		System.out.println(o.a);
		
		add();
		
	}
	public static void add()
	{
		System.out.println(b);
		

		variableEx o =new variableEx();
		System.out.println(o);
		o.a =333;
		System.out.println(o.a);
		
		//System.out.println(d); //canot access
	}

}
