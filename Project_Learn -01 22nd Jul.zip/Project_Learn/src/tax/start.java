package tax;

public class start 
{

	//data member or global variables
	static int a;	
	int b;
	
	//function /method 
	public static void main(String[] aa) 
	{
		System.out.println("hi "+aa[0]);

	}

}
