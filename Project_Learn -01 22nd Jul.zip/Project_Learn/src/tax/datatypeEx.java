package tax;

public class datatypeEx {

	public static void main(String[] args) {

		float a = 333.333f;
		System.out.println(a);
	
		char c='%';
		System.out.println(c);
		
		String name="ksjjsghj344333";
		System.out.println(name);
		
		
		//type casting : implicit and explicit type cast
		int aa=11;
		long dd=333;
		
		dd=aa; //implicit typecasting 
			
		aa =(int) dd; //explicit typecasting
		
		
		
		

	}

}
