package tax;

import java.util.Scanner;

public class operatorEx {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		
		int i,j;
		i =0;
		j =0;
		System.out.println(i++); // 0 
		System.out.println(++j);//  1
		
		System.out.println(i);//  1
		System.out.println(j);//  1
		
		System.out.println("enter data : ");
		i = sc.nextInt();
		System.out.println("you have entered :" +i);
		
				
	}

}
